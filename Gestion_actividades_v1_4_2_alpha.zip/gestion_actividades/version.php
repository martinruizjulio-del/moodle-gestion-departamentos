<?php
// This file is part of Moodle - http://moodle.org/
//
// Gestion_actividades local plugin.

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_gestion_actividades';
$plugin->version = 2026071069;
$plugin->requires  = 2022041900; // Moodle 4.0+.
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release = '1.4.2-alpha';
